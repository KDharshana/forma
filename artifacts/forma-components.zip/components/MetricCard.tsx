import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { colors } from "./theme";
import { Icon } from "./Icon";

export type MetricPoint = { label: string; value: number };
export function MetricCard({
  title = "Total revenue",
  value = "$24,680",
  change = "+18.6%",
  points,
  accent = colors.lime,
}: {
  title?: string;
  value?: string;
  change?: string;
  points: MetricPoint[];
  accent?: string;
}) {
  const max = Math.max(...points.map((p) => Math.max(0, p.value)), 1);
  return (
    <View style={s.card}>
      <View style={s.row}>
        <Text style={s.label}>{title}</Text>
        <Icon name="arrowUp" size={17} color="#b8beb1" />
      </View>
      <View style={[s.row, { marginTop: 14, alignItems: "baseline" }]}>
        <Text style={s.value}>{value}</Text>
        <Text style={[s.change, { color: accent }]}>{change} ↗</Text>
      </View>
      <Text style={s.caption}>compared to last month</Text>
      <View
        style={s.chart}
        accessibilityLabel={points
          .map((p) => `${p.label}: ${p.value}`)
          .join(", ")}
      >
        {points.map((point, i) => (
          <View style={s.column} key={`${point.label}-${i}`}>
            <View
              style={[
                s.bar,
                {
                  height: Math.max(4, (Math.max(0, point.value) / max) * 66),
                  backgroundColor: i === points.length - 1 ? accent : "#454c3d",
                },
              ]}
            />
            <Text style={s.axis}>{point.label}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}
const s = StyleSheet.create({
  card: {
    width: "100%",
    backgroundColor: "#262d23",
    borderRadius: 22,
    padding: 22,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  label: { color: "#c5c9bf", fontSize: 12 },
  value: {
    color: "#fff",
    fontSize: 32,
    fontWeight: "500",
    letterSpacing: -1.2,
  },
  change: { fontSize: 11 },
  caption: { color: "#8f9887", fontSize: 10, marginTop: 5 },
  chart: {
    height: 96,
    flexDirection: "row",
    alignItems: "flex-end",
    gap: 10,
    marginTop: 14,
  },
  column: { flex: 1, alignItems: "center", gap: 9 },
  bar: { width: "100%", borderTopLeftRadius: 5, borderTopRightRadius: 5 },
  axis: { fontSize: 9, color: "#9ba392" },
});
