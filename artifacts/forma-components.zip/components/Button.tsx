import React from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  ViewStyle,
} from "react-native";
import { colors } from "./theme";
import { Icon, IconName } from "./Icon";

export type ButtonProps = {
  children: string;
  onPress?: () => void;
  variant?: "primary" | "secondary" | "outline" | "ghost";
  accent?: string;
  icon?: IconName;
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
};
export function Button({
  children,
  onPress,
  variant = "primary",
  accent = colors.lime,
  icon,
  disabled,
  loading,
  style,
}: ButtonProps) {
  const foreground = variant === "primary" ? "#fff" : colors.ink;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{
        disabled: !!disabled || !!loading,
        busy: !!loading,
      }}
      disabled={disabled || loading}
      onPress={onPress}
      style={({ pressed }) => [
        s.button,
        {
          backgroundColor:
            variant === "primary"
              ? colors.ink
              : variant === "secondary"
                ? accent
                : "transparent",
          borderColor: variant === "outline" ? colors.line : "transparent",
          opacity: disabled ? 0.4 : pressed ? 0.7 : 1,
          transform: [{ scale: pressed ? 0.97 : 1 }],
        },
        style,
      ]}
    >
      {loading && <ActivityIndicator size="small" color={foreground} />}
      <Text style={[s.text, { color: foreground }]}>{children}</Text>
      {icon && !loading && <Icon name={icon} size={16} color={foreground} />}
    </Pressable>
  );
}
const s = StyleSheet.create({
  button: {
    minHeight: 44,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 30,
    borderWidth: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },
  text: { fontSize: 13, fontWeight: "500" },
});
