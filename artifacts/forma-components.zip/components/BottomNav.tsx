import React from "react";
import { View, Text, Pressable, StyleSheet } from "react-native";
import { Icon, IconName } from "./Icon";
import { colors } from "./theme";

export type NavItem = { id: string; label: string; icon: IconName };
export function BottomNav({
  items,
  value,
  onChange,
  accent = colors.lime,
}: {
  items: NavItem[];
  value: string;
  onChange: (id: string) => void;
  accent?: string;
}) {
  return (
    <View style={s.nav} accessibilityRole="tablist">
      {items.map((item) => (
        <Pressable
          key={item.id}
          accessibilityRole="tab"
          accessibilityLabel={item.label}
          aria-selected={item.id === value}
          accessibilityState={{ selected: item.id === value }}
          onPress={() => onChange(item.id)}
          style={({ pressed }) => [
            s.item,
            {
              backgroundColor: item.id === value ? accent : "transparent",
              opacity: pressed ? 0.6 : 1,
            },
          ]}
        >
          <Icon
            name={item.icon}
            color={item.id === value ? colors.ink : "#b7bcaf"}
            size={19}
          />
          {item.id === value && <Text style={s.label}>{item.label}</Text>}
        </Pressable>
      ))}
    </View>
  );
}
const s = StyleSheet.create({
  nav: {
    backgroundColor: "#262d23",
    padding: 7,
    borderRadius: 40,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 3,
  },
  item: {
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    justifyContent: "center",
    minWidth: 44,
    minHeight: 46,
    borderRadius: 30,
    paddingHorizontal: 13,
  },
  label: { fontSize: 11, fontWeight: "500", color: colors.ink },
});
