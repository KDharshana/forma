import React from "react";
import { Pressable, View, Text, StyleSheet } from "react-native";
import { colors } from "./theme";
import { Icon } from "./Icon";
import { AvatarGroup, Person } from "./AvatarGroup";
import { Badge } from "./Badge";

export function TaskCard({
  title,
  description,
  people,
  progress,
  due,
  completed,
  onToggle,
  accent = colors.lime,
}: {
  title: string;
  description: string;
  people: Person[];
  progress: number;
  due: string;
  completed: boolean;
  onToggle: () => void;
  accent?: string;
}) {
  const percent = completed ? 100 : Math.max(0, Math.min(100, progress));
  return (
    <View style={s.card}>
      <View style={s.row}>
        <Badge tone={completed ? "success" : "lavender"}>
          {completed ? "Completed" : "In progress"}
        </Badge>
        <Pressable
          accessibilityRole="checkbox"
          accessibilityLabel={`Complete ${title}`}
          aria-checked={completed}
          accessibilityState={{ checked: completed }}
          onPress={onToggle}
          style={s.checkTarget}
        >
          <View
            style={[
              s.checkbox,
              completed && { backgroundColor: accent, borderColor: accent },
            ]}
          >
            {completed && <Icon name="check" size={13} />}
          </View>
        </Pressable>
      </View>
      <Text
        style={[s.title, completed && { textDecorationLine: "line-through" }]}
      >
        {title}
      </Text>
      <Text style={s.description}>{description}</Text>
      <View style={[s.row, { marginTop: 19 }]}>
        <AvatarGroup people={people} size={30} />
        <View style={{ flexDirection: "row", gap: 5, alignItems: "center" }}>
          <Icon name="calendar" size={12} color={colors.muted} />
          <Text style={s.due}>{due}</Text>
        </View>
      </View>
      <View style={[s.row, { marginTop: 19 }]}>
        <Text style={s.due}>Progress</Text>
        <Text style={s.percent}>{percent}%</Text>
      </View>
      <View
        accessibilityRole="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={percent}
        accessibilityValue={{ min: 0, max: 100, now: percent }}
        style={s.track}
      >
        <View
          style={[
            s.progress,
            { width: `${percent}%`, backgroundColor: accent },
          ]}
        />
      </View>
    </View>
  );
}
const s = StyleSheet.create({
  card: {
    backgroundColor: "#fff",
    borderRadius: 21,
    padding: 21,
    width: "100%",
    borderWidth: 1,
    borderColor: "#eaebe5",
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  checkTarget: {
    minWidth: 44,
    minHeight: 44,
    alignItems: "flex-end",
    justifyContent: "center",
    marginVertical: -10,
  },
  checkbox: {
    width: 18,
    height: 18,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: "#d8dcd1",
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 16,
    color: colors.ink,
    fontWeight: "600",
    marginTop: 16,
    letterSpacing: -0.3,
  },
  description: { color: "#747c6b", fontSize: 11, lineHeight: 17, marginTop: 7 },
  due: { fontSize: 10, color: colors.muted },
  percent: { fontSize: 10, fontWeight: "600", color: colors.ink },
  track: {
    height: 5,
    backgroundColor: "#f0f2ea",
    borderRadius: 4,
    marginTop: 8,
  },
  progress: { height: 5, borderRadius: 4 },
});
