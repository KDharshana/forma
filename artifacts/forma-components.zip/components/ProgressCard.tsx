import React from "react";
import { Text, View, StyleSheet } from "react-native";
import Svg, { Circle } from "react-native-svg";
import { colors } from "./theme";

export function ProgressCard({
  value,
  title = "A little closer, every day.",
  subtitle = "Your weekly goal",
  accent = colors.lime,
}: {
  value: number;
  title?: string;
  subtitle?: string;
  accent?: string;
}) {
  const percent = Math.max(0, Math.min(100, value));
  const circumference = 2 * Math.PI * 54;
  return (
    <View style={s.card}>
      <Text style={s.subtitle}>{subtitle}</Text>
      <View
        style={s.ring}
        accessibilityRole="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={percent}
        accessibilityValue={{ min: 0, max: 100, now: percent }}
      >
        <Svg width={138} height={138} viewBox="0 0 138 138">
          <Circle
            cx={69}
            cy={69}
            r={54}
            stroke="#e5e9df"
            strokeWidth={10}
            fill="none"
          />
          <Circle
            cx={69}
            cy={69}
            r={54}
            stroke={accent}
            strokeWidth={10}
            fill="none"
            strokeLinecap="round"
            strokeDasharray={`${circumference} ${circumference}`}
            strokeDashoffset={circumference * (1 - percent / 100)}
            transform="rotate(-90 69 69)"
          />
        </Svg>
        <View style={s.center}>
          <Text style={s.value}>
            {percent}
            <Text style={s.percent}>%</Text>
          </Text>
          <Text style={s.complete}>completed</Text>
        </View>
      </View>
      <Text style={s.title}>{title}</Text>
    </View>
  );
}
const s = StyleSheet.create({
  card: {
    width: "100%",
    borderRadius: 22,
    backgroundColor: "#fff",
    padding: 20,
    alignItems: "center",
  },
  subtitle: { color: colors.muted, fontSize: 11 },
  ring: {
    marginVertical: 5,
    width: 138,
    height: 138,
    alignItems: "center",
    justifyContent: "center",
  },
  center: { position: "absolute", alignItems: "center" },
  value: { fontSize: 36, letterSpacing: -1.5, color: colors.ink },
  percent: { fontSize: 19 },
  complete: { fontSize: 9, color: colors.muted, marginTop: 2 },
  title: { color: colors.ink, fontSize: 12, fontWeight: "500", marginTop: 5 },
});
