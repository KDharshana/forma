import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { colors } from "./theme";

export function SegmentedControl<T extends string>({
  options,
  value,
  onChange,
  accent = colors.ink,
}: {
  options: readonly T[];
  value: T;
  onChange: (value: T) => void;
  accent?: string;
}) {
  return (
    <View style={s.track} accessibilityRole="tablist">
      {options.map((option) => (
        <Pressable
          key={option}
          accessibilityRole="tab"
          aria-selected={value === option}
          accessibilityState={{ selected: value === option }}
          onPress={() => onChange(option)}
          style={({ pressed }) => [
            s.item,
            {
              backgroundColor: value === option ? accent : "transparent",
              opacity: pressed ? 0.65 : 1,
            },
          ]}
        >
          <Text
            style={[
              s.label,
              {
                color:
                  value === option && accent === colors.ink
                    ? "#fff"
                    : colors.ink,
              },
            ]}
          >
            {option}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}
const s = StyleSheet.create({
  track: {
    flexDirection: "row",
    borderRadius: 30,
    backgroundColor: "#f2f3ee",
    padding: 4,
  },
  item: {
    flex: 1,
    minHeight: 44,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 24,
    paddingHorizontal: 12,
  },
  label: { fontSize: 11, fontWeight: "500" },
});
