import React from "react";
import { View, Text, Switch, StyleSheet } from "react-native";
import { colors } from "./theme";
import { Icon, IconName } from "./Icon";

export function ToggleRow({
  title,
  description,
  value,
  onChange,
  icon = "bell",
  accent = colors.lime,
}: {
  title: string;
  description?: string;
  value: boolean;
  onChange: (value: boolean) => void;
  icon?: IconName;
  accent?: string;
}) {
  return (
    <View style={s.row}>
      <View style={s.icon}>
        <Icon name={icon} size={18} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={s.title}>{title}</Text>
        {description && <Text style={s.description}>{description}</Text>}
      </View>
      <Switch
        accessibilityLabel={title}
        value={value}
        onValueChange={onChange}
        trackColor={{ false: "#e3e5df", true: accent }}
        thumbColor="#fff"
      />
    </View>
  );
}
const s = StyleSheet.create({
  row: {
    minHeight: 66,
    flexDirection: "row",
    alignItems: "center",
    gap: 13,
    paddingVertical: 14,
  },
  icon: {
    width: 38,
    height: 38,
    borderRadius: 13,
    backgroundColor: "#f4f5ef",
    alignItems: "center",
    justifyContent: "center",
  },
  title: { color: colors.ink, fontSize: 12, fontWeight: "500" },
  description: { color: colors.muted, fontSize: 10, marginTop: 5 },
});
