import { Platform } from "react-native";

export const colors = {
  ink: "#232621",
  muted: "#72796b",
  line: "#e7e9e2",
  paper: "#ffffff",
  canvas: "#f7f8f5",
  lime: "#d4ef78",
  lavender: "#d9cafa",
  teal: "#c3e6df",
};
export const mono = Platform.select({
  ios: "Menlo",
  android: "monospace",
  default: "monospace",
});
export const cardShadow = { boxShadow: "0px 6px 22px rgba(36, 43, 29, 0.04)" };
