import React from "react";
import { StyleSheet, Text, View } from "react-native";

const tones = {
  success: ["#e5efd9", "#4b6832"],
  warning: ["#fbefda", "#916a20"],
  neutral: ["#f0f1ed", "#65695f"],
  lavender: ["#ece4fb", "#7d61a6"],
};
export function Badge({
  children,
  tone = "neutral",
  dot = true,
}: {
  children: string;
  tone?: keyof typeof tones;
  dot?: boolean;
}) {
  const [backgroundColor, color] = tones[tone];
  return (
    <View style={[s.badge, { backgroundColor }]}>
      {dot && <View style={[s.dot, { backgroundColor: color }]} />}
      <Text style={[s.text, { color }]}>{children}</Text>
    </View>
  );
}
const s = StyleSheet.create({
  badge: {
    alignSelf: "flex-start",
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  dot: { width: 5, height: 5, borderRadius: 4 },
  text: { fontSize: 10, fontWeight: "500" },
});
