import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TextInputProps,
} from "react-native";
import { colors } from "./theme";
import { Icon, IconName } from "./Icon";

export type InputProps = TextInputProps & {
  label: string;
  error?: string;
  hint?: string;
  icon?: IconName;
  accent?: string;
};
export function Input({
  label,
  error,
  hint,
  icon,
  accent = colors.lime,
  ...props
}: InputProps) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={s.wrapper}>
      <Text style={s.label}>{label}</Text>
      <View
        style={[
          s.field,
          {
            borderColor: error ? "#b94e45" : focused ? "#70833f" : "#e5e8df",
            backgroundColor: focused ? "#fff" : "#fafbf8",
          },
        ]}
      >
        {icon && <Icon name={icon} size={16} color={colors.muted} />}
        <TextInput
          {...props}
          accessibilityLabel={label}
          placeholderTextColor="#a2a699"
          selectionColor={accent}
          onFocus={(e) => {
            setFocused(true);
            props.onFocus?.(e);
          }}
          onBlur={(e) => {
            setFocused(false);
            props.onBlur?.(e);
          }}
          style={[s.input, props.style]}
        />
      </View>
      {(error || hint) && (
        <Text
          accessibilityLiveRegion="polite"
          style={[s.hint, error ? { color: "#b94e45" } : {}]}
        >
          {error || hint}
        </Text>
      )}
    </View>
  );
}
const s = StyleSheet.create({
  wrapper: { gap: 8, width: "100%" },
  label: { fontSize: 11, fontWeight: "500", color: colors.ink },
  field: {
    minHeight: 47,
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 13,
    gap: 9,
    flexDirection: "row",
    alignItems: "center",
  },
  input: {
    flex: 1,
    minWidth: 0,
    paddingVertical: 12,
    fontSize: 12,
    color: colors.ink,
    outlineWidth: 0,
  },
  hint: { fontSize: 10, lineHeight: 15, color: colors.muted },
});
