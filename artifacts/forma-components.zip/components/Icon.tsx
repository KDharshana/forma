import React from "react";
import { Platform } from "react-native";
import Svg, { Path, Circle, Rect } from "react-native-svg";

export type IconName =
  | "arrow"
  | "arrowUp"
  | "chevron"
  | "chevronLeft"
  | "check"
  | "plus"
  | "close"
  | "search"
  | "grid"
  | "layers"
  | "code"
  | "copy"
  | "home"
  | "chart"
  | "users"
  | "settings"
  | "calendar"
  | "bell"
  | "wallet"
  | "book"
  | "spark"
  | "external"
  | "menu"
  | "filter"
  | "download"
  | "phone"
  | "mail"
  | "sun";
const paths: Record<IconName, string> = {
  arrow: "M4 12h16m-6-6 6 6-6 6",
  arrowUp: "M6 18 18 6M6 6h12v12",
  chevron: "m9 5 7 7-7 7",
  chevronLeft: "m15 5-7 7 7 7",
  check: "m5 12 4 4L19 6",
  plus: "M12 5v14M5 12h14",
  close: "m6 6 12 12M6 18 18 6",
  search: "m16 16 4 4",
  grid: "M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z",
  layers: "m12 3 10 5-10 5L2 8l10-5Zm-10 9 10 5 10-5M2 16l10 5 10-5",
  code: "m8 7-5 5 5 5m8-10 5 5-5 5M14 4l-4 16",
  copy: "M8 8h12v12H8zM16 8V4H4v12h4",
  home: "m3 10 9-7 9 7v11h-6v-8H9v8H3V10Z",
  chart: "M4 3v17h17M8 16v-5m5 5V7m5 9V3",
  users: "M3 21v-3a5 5 0 0 1 10 0v3m4-8a5 5 0 0 1 5 5v3M16 3a4 4 0 0 1 0 8",
  settings: "M9 3h6l1 4 4 1v7l-4 1-1 5H9l-1-5-5-1V8l5-1 1-4Z",
  calendar: "M4 5h16v16H4zM4 10h16M8 3v4m8-4v4M8 14h2m4 0h2m-8 3h2",
  bell: "M18 8a6 6 0 0 0-12 0c0 8-3 8-3 9h18c0-1-3-1-3-9M10 21h4",
  wallet: "M3 5h17v15H3zM20 10h-7v5h7M3 5V3h13",
  book: "M3 3h7l2 2 2-2h7v17h-7l-2 2-2-2H3V3Zm9 2v17",
  spark: "m12 2 3 7 7 3-7 3-3 7-3-7-7-3 7-3 3-7Z",
  external: "M13 3h8v8M10 14 21 3M9 3H3v18h18v-6",
  menu: "M4 6h16M4 12h16M4 18h16",
  filter: "M3 6h18M6 12h12M9 18h6",
  download: "M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5",
  phone: "M7 2h10v20H7zM10 18h4",
  mail: "M3 5h18v14H3zM3 5l9 8 9-8",
  sun: "M12 1v3m0 16v3M1 12h3m16 0h3M4 4l2 2m12 12 2 2M4 20l2-2M18 6l2-2",
};
export function Icon({
  name,
  size = 18,
  color = "#232621",
  strokeWidth = 1.6,
}: {
  name: IconName;
  size?: number;
  color?: string;
  strokeWidth?: number;
}) {
  return (
    <Svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      {...(Platform.OS === "web"
        ? { "aria-hidden": true }
        : {
            accessibilityElementsHidden: true,
            importantForAccessibility: "no-hide-descendants" as const,
          })}
    >
      <Path d={paths[name]} />
      {name === "search" && <Circle cx="10.5" cy="10.5" r="6.5" />}
      {name === "users" && <Circle cx="8" cy="7" r="4" />}
      {name === "settings" && <Circle cx="12" cy="12" r="3" />}
      {name === "sun" && <Circle cx="12" cy="12" r="5" />}
    </Svg>
  );
}
