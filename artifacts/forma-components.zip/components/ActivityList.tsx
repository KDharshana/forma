import React from "react";
import { View, Text, StyleSheet, Pressable } from "react-native";
import { Icon, IconName } from "./Icon";
import { colors } from "./theme";

export type Activity = {
  id: string;
  title: string;
  subtitle: string;
  amount: string;
  icon: IconName;
  color: string;
};
export function ActivityList({
  items,
  onSelect,
}: {
  items: Activity[];
  onSelect: (item: Activity) => void;
}) {
  return (
    <View style={s.card}>
      <View style={s.heading}>
        <Text style={s.title}>Recent activity</Text>
        <Text style={s.today}>Today</Text>
      </View>
      {items.map((item, i) => (
        <Pressable
          key={item.id}
          accessibilityRole="button"
          accessibilityLabel={`${item.title}, ${item.amount}, ${item.subtitle}`}
          onPress={() => onSelect(item)}
          style={({ pressed }) => [
            s.row,
            i !== items.length - 1 && s.border,
            { opacity: pressed ? 0.6 : 1 },
          ]}
        >
          <View style={[s.icon, { backgroundColor: item.color }]}>
            <Icon name={item.icon} size={17} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.name}>{item.title}</Text>
            <Text style={s.subtitle}>{item.subtitle}</Text>
          </View>
          <Text style={s.amount}>{item.amount}</Text>
        </Pressable>
      ))}
    </View>
  );
}
const s = StyleSheet.create({
  card: {
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 22,
    width: "100%",
  },
  heading: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 15,
    alignItems: "center",
  },
  title: { fontSize: 14, color: colors.ink, fontWeight: "500" },
  today: { fontSize: 10, color: colors.muted },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingVertical: 13,
    minHeight: 56,
  },
  border: { borderBottomWidth: 1, borderColor: "#f0f1ec" },
  icon: {
    width: 35,
    height: 35,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  name: { fontSize: 11, fontWeight: "500", color: colors.ink },
  subtitle: { fontSize: 9, color: colors.muted, marginTop: 5 },
  amount: { fontSize: 11, fontWeight: "500", color: colors.ink },
});
