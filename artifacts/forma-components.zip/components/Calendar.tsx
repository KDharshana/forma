import React, { useEffect, useState } from "react";
import { View, Text, Pressable, StyleSheet } from "react-native";
import { colors } from "./theme";
import { Icon } from "./Icon";

export function Calendar({
  value,
  onChange,
  accent = colors.lime,
}: {
  value: Date;
  onChange: (date: Date) => void;
  accent?: string;
}) {
  const [month, setMonth] = useState(
    () => new Date(value.getFullYear(), value.getMonth(), 1),
  );
  const selectedYear = value.getFullYear();
  const selectedMonth = value.getMonth();
  useEffect(() => {
    setMonth(new Date(selectedYear, selectedMonth, 1));
  }, [selectedYear, selectedMonth]);
  const year = month.getFullYear();
  const m = month.getMonth();
  const offset = (new Date(year, m, 1).getDay() + 6) % 7;
  const days = new Date(year, m + 1, 0).getDate();
  const total = Math.ceil((offset + days) / 7) * 7;
  return (
    <View style={s.card}>
      <View style={s.heading}>
        <Text style={s.title}>
          {month.toLocaleDateString("en-US", {
            month: "long",
            year: "numeric",
          })}
        </Text>
        <View style={{ flexDirection: "row" }}>
          {[-1, 1].map((direction) => (
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={
                direction < 0 ? "Previous month" : "Next month"
              }
              key={direction}
              onPress={() => setMonth(new Date(year, m + direction, 1))}
              style={s.arrow}
            >
              <Icon
                name={direction < 0 ? "chevronLeft" : "chevron"}
                size={13}
              />
            </Pressable>
          ))}
        </View>
      </View>
      <View style={s.grid}>
        {["M", "T", "W", "T", "F", "S", "S"].map((day, i) => (
          <View key={i} style={s.day}>
            <Text style={s.weekday}>{day}</Text>
          </View>
        ))}
        {Array.from({ length: total }, (_, i) => {
          const day = i - offset + 1;
          const valid = day > 0 && day <= days;
          const selected =
            valid &&
            value.getFullYear() === year &&
            value.getMonth() === m &&
            value.getDate() === day;
          return valid ? (
            <Pressable
              key={i}
              accessibilityRole="button"
              accessibilityLabel={new Date(year, m, day).toLocaleDateString(
                "en-US",
                { dateStyle: "full" },
              )}
              aria-selected={selected}
              accessibilityState={{ selected }}
              onPress={() => onChange(new Date(year, m, day))}
              style={s.day}
            >
              <View
                style={[s.numberWrap, selected && { backgroundColor: accent }]}
              >
                <Text style={[s.number, selected && { fontWeight: "600" }]}>
                  {day}
                </Text>
              </View>
            </Pressable>
          ) : (
            <View key={i} style={s.day} />
          );
        })}
      </View>
    </View>
  );
}
const s = StyleSheet.create({
  card: {
    backgroundColor: "#fff",
    borderRadius: 22,
    padding: 15,
    width: "100%",
  },
  heading: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 6,
  },
  title: { fontSize: 13, fontWeight: "500", color: colors.ink },
  arrow: {
    width: 44,
    height: 44,
    justifyContent: "center",
    alignItems: "center",
  },
  grid: { flexDirection: "row", flexWrap: "wrap" },
  day: {
    width: "14.285714%",
    minHeight: 44,
    flexGrow: 0,
    justifyContent: "center",
    alignItems: "center",
  },
  weekday: { fontSize: 9, color: colors.muted },
  numberWrap: {
    width: 30,
    height: 30,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  number: { color: colors.ink, fontSize: 12 },
});
