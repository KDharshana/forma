import React from "react";
import { View, Text, StyleSheet } from "react-native";

export type Person = { name: string; color?: string };
const shades = ["#ddc7b4", "#cad7bf", "#d6c6e4", "#bfd4d9"];
export function AvatarGroup({
  people,
  max = 3,
  size = 34,
}: {
  people: Person[];
  max?: number;
  size?: number;
}) {
  const visible = people.slice(0, Math.max(1, max));
  return (
    <View
      accessibilityLabel={people.map((p) => p.name).join(", ")}
      style={s.row}
    >
      {visible.map((person, i) => (
        <View
          key={`${person.name}-${i}`}
          style={[
            s.avatar,
            {
              width: size,
              height: size,
              borderRadius: size / 2,
              marginLeft: i ? -9 : 0,
              backgroundColor: person.color || shades[i % shades.length],
            },
          ]}
        >
          <Text style={[s.initials, { fontSize: size * 0.3 }]}>
            {person.name
              .split(" ")
              .slice(0, 2)
              .map((n) => n[0])
              .join("")}
          </Text>
        </View>
      ))}
      {people.length > visible.length && (
        <View
          style={[
            s.avatar,
            {
              width: size,
              height: size,
              borderRadius: size / 2,
              marginLeft: -9,
              backgroundColor: "#f0f1ed",
            },
          ]}
        >
          <Text style={[s.initials, { fontSize: size * 0.3 }]}>
            +{people.length - visible.length}
          </Text>
        </View>
      )}
    </View>
  );
}
const s = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center" },
  avatar: {
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "#fff",
  },
  initials: { color: "#41483b", fontWeight: "600" },
});
